﻿Imports System.Drawing
Imports System.Windows.Forms

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDataPelanggan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblIDPelanggan = New Label()
        txtIDPelanggan = New TextBox()
        lblNamaPelanggan = New Label()
        txtNamaPelanggan = New TextBox()
        lblTanggalTransaksi = New Label()
        dtpTanggalTransaksi = New DateTimePicker()
        lblJenisPaket = New Label()
        cmbJenisPaket = New ComboBox()
        lblHargaJam = New Label()
        txtHargaJam = New TextBox()
        lblLamaMain = New Label()
        txtLamaMain = New TextBox()
        lblPotongan = New Label()
        txtPotongan = New TextBox()
        lblTotalBayar = New Label()
        txtTotalBayar = New TextBox()
        btnTambah = New Button()
        btnSimpan = New Button()
        btnBatal = New Button()
        btnUpdate = New Button()
        btnHapus = New Button()
        btnKeluar = New Button()
        dgvPelanggan = New DataGridView()
        CType(dgvPelanggan, System.ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblIDPelanggan
        ' 
        lblIDPelanggan.AutoSize = True
        lblIDPelanggan.Location = New Point(40, 46)
        lblIDPelanggan.Margin = New Padding(4, 0, 4, 0)
        lblIDPelanggan.Name = "lblIDPelanggan"
        lblIDPelanggan.Size = New Size(100, 20)
        lblIDPelanggan.TabIndex = 0
        lblIDPelanggan.Text = "ID Pelanggan:"
        ' 
        ' txtIDPelanggan
        ' 
        txtIDPelanggan.BackColor = Color.LightGray
        txtIDPelanggan.Location = New Point(200, 42)
        txtIDPelanggan.Margin = New Padding(4, 5, 4, 5)
        txtIDPelanggan.Name = "txtIDPelanggan"
        txtIDPelanggan.ReadOnly = True
        txtIDPelanggan.Size = New Size(265, 27)
        txtIDPelanggan.TabIndex = 1
        ' 
        ' lblNamaPelanggan
        ' 
        lblNamaPelanggan.AutoSize = True
        lblNamaPelanggan.Location = New Point(40, 92)
        lblNamaPelanggan.Margin = New Padding(4, 0, 4, 0)
        lblNamaPelanggan.Name = "lblNamaPelanggan"
        lblNamaPelanggan.Size = New Size(125, 20)
        lblNamaPelanggan.TabIndex = 2
        lblNamaPelanggan.Text = "Nama Pelanggan:"
        ' 
        ' txtNamaPelanggan
        ' 
        txtNamaPelanggan.Location = New Point(200, 88)
        txtNamaPelanggan.Margin = New Padding(4, 5, 4, 5)
        txtNamaPelanggan.Name = "txtNamaPelanggan"
        txtNamaPelanggan.Size = New Size(265, 27)
        txtNamaPelanggan.TabIndex = 3
        ' 
        ' lblTanggalTransaksi
        ' 
        lblTanggalTransaksi.AutoSize = True
        lblTanggalTransaksi.Location = New Point(40, 138)
        lblTanggalTransaksi.Margin = New Padding(4, 0, 4, 0)
        lblTanggalTransaksi.Name = "lblTanggalTransaksi"
        lblTanggalTransaksi.Size = New Size(127, 20)
        lblTanggalTransaksi.TabIndex = 4
        lblTanggalTransaksi.Text = "Tanggal Transaksi:"
        ' 
        ' dtpTanggalTransaksi
        ' 
        dtpTanggalTransaksi.Format = DateTimePickerFormat.Short
        dtpTanggalTransaksi.Location = New Point(200, 134)
        dtpTanggalTransaksi.Margin = New Padding(4, 5, 4, 5)
        dtpTanggalTransaksi.Name = "dtpTanggalTransaksi"
        dtpTanggalTransaksi.Size = New Size(265, 27)
        dtpTanggalTransaksi.TabIndex = 5
        ' 
        ' lblJenisPaket
        ' 
        lblJenisPaket.AutoSize = True
        lblJenisPaket.Location = New Point(40, 185)
        lblJenisPaket.Margin = New Padding(4, 0, 4, 0)
        lblJenisPaket.Name = "lblJenisPaket"
        lblJenisPaket.Size = New Size(82, 20)
        lblJenisPaket.TabIndex = 6
        lblJenisPaket.Text = "Jenis Paket:"
        ' 
        ' cmbJenisPaket
        ' 
        cmbJenisPaket.DropDownStyle = ComboBoxStyle.DropDownList
        cmbJenisPaket.FormattingEnabled = True
        cmbJenisPaket.Location = New Point(200, 180)
        cmbJenisPaket.Margin = New Padding(4, 5, 4, 5)
        cmbJenisPaket.Name = "cmbJenisPaket"
        cmbJenisPaket.Size = New Size(265, 28)
        cmbJenisPaket.TabIndex = 7
        ' 
        ' lblHargaJam
        ' 
        lblHargaJam.AutoSize = True
        lblHargaJam.Location = New Point(40, 231)
        lblHargaJam.Margin = New Padding(4, 0, 4, 0)
        lblHargaJam.Name = "lblHargaJam"
        lblHargaJam.Size = New Size(85, 20)
        lblHargaJam.TabIndex = 8
        lblHargaJam.Text = "Harga/Jam:"
        ' 
        ' txtHargaJam
        ' 
        txtHargaJam.BackColor = Color.LightGray
        txtHargaJam.Location = New Point(200, 226)
        txtHargaJam.Margin = New Padding(4, 5, 4, 5)
        txtHargaJam.Name = "txtHargaJam"
        txtHargaJam.ReadOnly = True
        txtHargaJam.Size = New Size(265, 27)
        txtHargaJam.TabIndex = 9
        ' 
        ' lblLamaMain
        ' 
        lblLamaMain.AutoSize = True
        lblLamaMain.Location = New Point(40, 277)
        lblLamaMain.Margin = New Padding(4, 0, 4, 0)
        lblLamaMain.Name = "lblLamaMain"
        lblLamaMain.Size = New Size(125, 20)
        lblLamaMain.TabIndex = 10
        lblLamaMain.Text = "Lama Main (Jam):"
        ' 
        ' txtLamaMain
        ' 
        txtLamaMain.Location = New Point(200, 272)
        txtLamaMain.Margin = New Padding(4, 5, 4, 5)
        txtLamaMain.Name = "txtLamaMain"
        txtLamaMain.Size = New Size(265, 27)
        txtLamaMain.TabIndex = 11
        ' 
        ' lblPotongan
        ' 
        lblPotongan.AutoSize = True
        lblPotongan.Location = New Point(40, 323)
        lblPotongan.Margin = New Padding(4, 0, 4, 0)
        lblPotongan.Name = "lblPotongan"
        lblPotongan.Size = New Size(75, 20)
        lblPotongan.TabIndex = 12
        lblPotongan.Text = "Potongan:"
        ' 
        ' txtPotongan
        ' 
        txtPotongan.BackColor = Color.LightGray
        txtPotongan.Location = New Point(200, 318)
        txtPotongan.Margin = New Padding(4, 5, 4, 5)
        txtPotongan.Name = "txtPotongan"
        txtPotongan.ReadOnly = True
        txtPotongan.Size = New Size(265, 27)
        txtPotongan.TabIndex = 13
        ' 
        ' lblTotalBayar
        ' 
        lblTotalBayar.AutoSize = True
        lblTotalBayar.Location = New Point(40, 369)
        lblTotalBayar.Margin = New Padding(4, 0, 4, 0)
        lblTotalBayar.Name = "lblTotalBayar"
        lblTotalBayar.Size = New Size(86, 20)
        lblTotalBayar.TabIndex = 14
        lblTotalBayar.Text = "Total Bayar:"
        ' 
        ' txtTotalBayar
        ' 
        txtTotalBayar.BackColor = Color.LightGray
        txtTotalBayar.Location = New Point(200, 365)
        txtTotalBayar.Margin = New Padding(4, 5, 4, 5)
        txtTotalBayar.Name = "txtTotalBayar"
        txtTotalBayar.ReadOnly = True
        txtTotalBayar.Size = New Size(265, 27)
        txtTotalBayar.TabIndex = 15
        ' 
        ' btnTambah
        ' 
        btnTambah.Location = New Point(40, 431)
        btnTambah.Margin = New Padding(4, 5, 4, 5)
        btnTambah.Name = "btnTambah"
        btnTambah.Size = New Size(100, 35)
        btnTambah.TabIndex = 16
        btnTambah.Text = "Tambah"
        btnTambah.UseVisualStyleBackColor = True
        ' 
        ' btnSimpan
        ' 
        btnSimpan.Location = New Point(148, 431)
        btnSimpan.Margin = New Padding(4, 5, 4, 5)
        btnSimpan.Name = "btnSimpan"
        btnSimpan.Size = New Size(100, 35)
        btnSimpan.TabIndex = 17
        btnSimpan.Text = "Simpan"
        btnSimpan.UseVisualStyleBackColor = True
        ' 
        ' btnBatal
        ' 
        btnBatal.Location = New Point(256, 431)
        btnBatal.Margin = New Padding(4, 5, 4, 5)
        btnBatal.Name = "btnBatal"
        btnBatal.Size = New Size(100, 35)
        btnBatal.TabIndex = 18
        btnBatal.Text = "Batal"
        btnBatal.UseVisualStyleBackColor = True
        ' 
        ' btnUpdate
        ' 
        btnUpdate.Location = New Point(364, 431)
        btnUpdate.Margin = New Padding(4, 5, 4, 5)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(100, 35)
        btnUpdate.TabIndex = 19
        btnUpdate.Text = "Update"
        btnUpdate.UseVisualStyleBackColor = True
        ' 
        ' btnHapus
        ' 
        btnHapus.Location = New Point(472, 431)
        btnHapus.Margin = New Padding(4, 5, 4, 5)
        btnHapus.Name = "btnHapus"
        btnHapus.Size = New Size(100, 35)
        btnHapus.TabIndex = 20
        btnHapus.Text = "Hapus"
        btnHapus.UseVisualStyleBackColor = True
        ' 
        ' btnKeluar
        ' 
        btnKeluar.Location = New Point(580, 431)
        btnKeluar.Margin = New Padding(4, 5, 4, 5)
        btnKeluar.Name = "btnKeluar"
        btnKeluar.Size = New Size(100, 35)
        btnKeluar.TabIndex = 21
        btnKeluar.Text = "Keluar"
        btnKeluar.UseVisualStyleBackColor = True
        ' 
        ' dgvPelanggan
        ' 
        dgvPelanggan.AllowUserToAddRows = False
        dgvPelanggan.AllowUserToDeleteRows = False
        dgvPelanggan.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvPelanggan.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvPelanggan.Location = New Point(40, 492)
        dgvPelanggan.Margin = New Padding(4, 5, 4, 5)
        dgvPelanggan.Name = "dgvPelanggan"
        dgvPelanggan.ReadOnly = True
        dgvPelanggan.RowHeadersWidth = 51
        dgvPelanggan.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvPelanggan.Size = New Size(1107, 338)
        dgvPelanggan.TabIndex = 22
        ' 
        ' frmDataPelanggan
        ' 
        AutoScaleDimensions = New SizeF(8.0F, 20.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1200, 993)
        Controls.Add(dgvPelanggan)
        Controls.Add(btnKeluar)
        Controls.Add(btnHapus)
        Controls.Add(btnUpdate)
        Controls.Add(btnBatal)
        Controls.Add(btnSimpan)
        Controls.Add(btnTambah)
        Controls.Add(txtTotalBayar)
        Controls.Add(lblTotalBayar)
        Controls.Add(txtPotongan)
        Controls.Add(lblPotongan)
        Controls.Add(txtLamaMain)
        Controls.Add(lblLamaMain)
        Controls.Add(txtHargaJam)
        Controls.Add(lblHargaJam)
        Controls.Add(cmbJenisPaket)
        Controls.Add(lblJenisPaket)
        Controls.Add(dtpTanggalTransaksi)
        Controls.Add(lblTanggalTransaksi)
        Controls.Add(txtNamaPelanggan)
        Controls.Add(lblNamaPelanggan)
        Controls.Add(txtIDPelanggan)
        Controls.Add(lblIDPelanggan)
        Margin = New Padding(4, 5, 4, 5)
        Name = "frmDataPelanggan"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Data Pelanggan Warnet"
        CType(dgvPelanggan, System.ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()

    End Sub

    Friend WithEvents lblIDPelanggan As Label
    Friend WithEvents txtIDPelanggan As TextBox
    Friend WithEvents lblNamaPelanggan As Label
    Friend WithEvents txtNamaPelanggan As TextBox
    Friend WithEvents lblTanggalTransaksi As Label
    Friend WithEvents dtpTanggalTransaksi As DateTimePicker
    Friend WithEvents lblJenisPaket As Label
    Friend WithEvents cmbJenisPaket As ComboBox
    Friend WithEvents lblHargaJam As Label
    Friend WithEvents txtHargaJam As TextBox
    Friend WithEvents lblLamaMain As Label
    Friend WithEvents txtLamaMain As TextBox
    Friend WithEvents lblPotongan As Label
    Friend WithEvents txtPotongan As TextBox
    Friend WithEvents lblTotalBayar As Label
    Friend WithEvents txtTotalBayar As TextBox
    Friend WithEvents btnTambah As Button
    Friend WithEvents btnSimpan As Button
    Friend WithEvents btnBatal As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnHapus As Button
    Friend WithEvents btnKeluar As Button
    Friend WithEvents dgvPelanggan As DataGridView
End Class