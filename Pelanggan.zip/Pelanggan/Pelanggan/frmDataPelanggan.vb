﻿Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.Windows.Forms

Public Class frmDataPelanggan

    ' Deklarasi Variable Global untuk Koneksi Database (sesuai MySQL)
    Private conn As MySqlConnection
    Private cmd As MySqlCommand
    Private da As MySqlDataAdapter
    Private ds As DataSet
    Private reader As MySqlDataReader

    ' Connection string MySQL
    Private connString As String = "server=localhost;uid=root;password=;database=Warnet_2421006"

    ' Variabel global untuk perhitungan
    Private hargaPaket As Decimal = 0
    Private totalBayarHasilHitung As Decimal = 0

    ' Constructor
    Public Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        ' Inisialisasi objek database di sini
        conn = New MySqlConnection(connString)
        cmd = New MySqlCommand()
        da = New MySqlDataAdapter()
        ds = New DataSet()
    End Sub

    ' Nonaktifkan kontrol input dan sesuaikan tombol
    Private Sub NonAktifkanKontrol()
        txtIDPelanggan.Enabled = False ' ID Pelanggan TIDAK BISA DIEDIT/INPUT MANUAL
        txtNamaPelanggan.Enabled = False
        dtpTanggalTransaksi.Enabled = False
        cmbJenisPaket.Enabled = False
        txtHargaJam.Enabled = False
        txtLamaMain.Enabled = False
        txtPotongan.Enabled = False
        txtTotalBayar.Enabled = False

        btnSimpan.Enabled = False
        btnBatal.Enabled = False
        btnUpdate.Enabled = False
        btnHapus.Enabled = False
        btnTambah.Enabled = True ' Selalu aktifkan tombol tambah saat tidak ada mode edit/tambah
    End Sub

    ' Aktifkan kontrol input dan sesuaikan tombol
    ' Catatan: txtIDPelanggan tetap False di sini untuk auto-increment
    Private Sub AktifkanKontrol()
        ' txtIDPelanggan.Enabled = True ' BARIS INI DIHAPUS/KOMENTARI
        txtNamaPelanggan.Enabled = True
        dtpTanggalTransaksi.Enabled = True
        cmbJenisPaket.Enabled = True
        txtLamaMain.Enabled = True

        btnSimpan.Enabled = True
        btnBatal.Enabled = True
        ' btnUpdate dan btnHapus diatur terpisah, tergantung apakah ada ID yang dipilih dari DGV
        btnUpdate.Enabled = False ' Defaultnya False, aktif jika ada data terpilih
        btnHapus.Enabled = False  ' Defaultnya False, aktif jika ada data terpilih
        btnTambah.Enabled = False
    End Sub

    ' Bersihkan input
    Private Sub BersihkanForm()
        txtIDPelanggan.Clear()
        txtNamaPelanggan.Clear()
        dtpTanggalTransaksi.Value = DateTime.Now
        cmbJenisPaket.SelectedIndex = -1
        txtHargaJam.Clear()
        txtLamaMain.Clear()
        txtPotongan.Clear()
        txtTotalBayar.Clear()
        hargaPaket = 0
        totalBayarHasilHitung = 0
    End Sub

    ' Tampilkan data ke DataGridView
    Private Sub TampilkanDataPelanggan()
        Try
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()
            ds.Clear()

            Dim query As String = "SELECT ID_PELANGGAN as 'ID', NAMA_PELANGGAN as 'Nama Pelanggan', TANGGAL_TRANSAKSI as 'Tanggal', JENIS_PAKET as 'Jenis Paket', HARGA_JAM as 'Harga/Jam', LAMA_MAIN as 'Lama Main', POTONGAN as 'Potongan', TOTAL_BAYAR as 'Total Bayar' FROM Pelanggan ORDER BY ID_PELANGGAN"

            cmd.Connection = conn
            cmd.CommandText = query
            da.SelectCommand = cmd
            da.Fill(ds, "Pelanggan")

            If ds.Tables("Pelanggan").Rows.Count > 0 Then
                dgvPelanggan.DataSource = ds.Tables("Pelanggan")

                ' Format kolom DataGridView
                If dgvPelanggan.Columns.Contains("Harga/Jam") Then
                    dgvPelanggan.Columns("Harga/Jam").DefaultCellStyle.Format = "N0"
                End If
                If dgvPelanggan.Columns.Contains("Potongan") Then
                    dgvPelanggan.Columns("Potongan").DefaultCellStyle.Format = "N0"
                End If
                If dgvPelanggan.Columns.Contains("Total Bayar") Then
                    dgvPelanggan.Columns("Total Bayar").DefaultCellStyle.Format = "N0"
                End If
                If dgvPelanggan.Columns.Contains("Tanggal") Then
                    dgvPelanggan.Columns("Tanggal").DefaultCellStyle.Format = "dd/MM/yyyy"
                End If

                dgvPelanggan.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill ' Auto resize columns

            Else
                dgvPelanggan.DataSource = Nothing ' Kosongkan DataGridView jika tidak ada data
            End If

        Catch ex As Exception
            MsgBox("Gagal menampilkan data: " & ex.Message, MsgBoxStyle.Critical, "Error Database")
        Finally
            If conn.State = ConnectionState.Open Then conn.Close()
        End Try
    End Sub

    ' Event Form Load
    Private Sub frmDataPelanggan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            NonAktifkanKontrol() ' Nonaktifkan kontrol saat form pertama kali dimuat
            BersihkanForm()
            LoadJenisPaket() ' Memuat jenis paket ke combobox
            TampilkanDataPelanggan() ' Memuat data pelanggan ke DataGridView

        Catch ex As Exception
            MsgBox("Error saat memuat form: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' Method untuk load jenis paket ke ComboBox
    Private Sub LoadJenisPaket()
        Try
            cmbJenisPaket.Items.Clear()
            cmbJenisPaket.Items.Add("Paket 1")
            cmbJenisPaket.Items.Add("Paket 2")
            cmbJenisPaket.Items.Add("Paket 3")
            cmbJenisPaket.Items.Add("Paket 4")
        Catch ex As Exception
            MsgBox("Error load jenis paket: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' Event ComboBox JenisPaket SelectedIndexChanged
    Private Sub cmbJenisPaket_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbJenisPaket.SelectedIndexChanged
        Try
            Select Case cmbJenisPaket.Text
                Case "Paket 1"
                    hargaPaket = 4500
                Case "Paket 2"
                    hargaPaket = 6500
                Case "Paket 3"
                    hargaPaket = 10000
                Case "Paket 4"
                    hargaPaket = 25000
                Case Else
                    hargaPaket = 0
            End Select
            txtHargaJam.Text = hargaPaket.ToString("N0")
            HitungTotal()
        Catch ex As Exception
            MsgBox("Error saat memilih paket: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' Event TextBox LamaMain TextChanged
    Private Sub txtLamaMain_TextChanged(sender As Object, e As EventArgs) Handles txtLamaMain.TextChanged
        HitungTotal()
    End Sub

    ' Event TextBox LamaMain KeyPress (hanya angka)
    Private Sub txtLamaMain_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtLamaMain.KeyPress
        If Not Char.IsDigit(e.KeyChar) And Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    ' Method untuk menghitung total bayar
    Private Sub HitungTotal()
        Try
            Dim lamaMain As Integer = 0
            Dim potongan As Decimal = 0

            If Integer.TryParse(txtLamaMain.Text, lamaMain) And lamaMain > 0 Then
                If lamaMain > 3 Then
                    potongan = 1000 * (lamaMain - 3)
                End If

                totalBayarHasilHitung = (hargaPaket * lamaMain) - potongan

                txtPotongan.Text = potongan.ToString("N0")
                txtTotalBayar.Text = totalBayarHasilHitung.ToString("N0")
            Else
                txtPotongan.Text = "0"
                txtTotalBayar.Text = "0"
                totalBayarHasilHitung = 0
            End If
        Catch ex As Exception
            txtPotongan.Text = "0"
            txtTotalBayar.Text = "0"
            totalBayarHasilHitung = 0
            MsgBox("Error dalam perhitungan: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' Method untuk validasi input
    Private Function ValidateInput() As Boolean
        Try
            If txtNamaPelanggan.Text.Trim() = "" Then
                MsgBox("Nama pelanggan harus diisi!", MsgBoxStyle.Exclamation, "Validasi")
                txtNamaPelanggan.Focus()
                Return False
            End If

            If cmbJenisPaket.SelectedIndex = -1 Then
                MsgBox("Jenis paket harus dipilih!", MsgBoxStyle.Exclamation, "Validasi")
                cmbJenisPaket.Focus()
                Return False
            End If

            If txtLamaMain.Text.Trim() = "" Then
                MsgBox("Lama main harus diisi!", MsgBoxStyle.Exclamation, "Validasi")
                txtLamaMain.Focus()
                Return False
            End If

            Dim lamaMainValue As Integer
            If Not Integer.TryParse(txtLamaMain.Text, lamaMainValue) Then
                MsgBox("Lama main harus berupa angka!", MsgBoxStyle.Exclamation, "Validasi")
                txtLamaMain.Focus()
                Return False
            End If

            If lamaMainValue <= 0 Then
                MsgBox("Lama main harus lebih dari 0!", MsgBoxStyle.Exclamation, "Validasi")
                txtLamaMain.Focus()
                Return False
            End If

            If totalBayarHasilHitung <= 0 Then
                MsgBox("Total bayar tidak valid! Pastikan harga dan lama main terisi dengan benar.", MsgBoxStyle.Exclamation, "Validasi")
                Return False
            End If

            Return True
        Catch ex As Exception
            MsgBox("Error validasi: " & ex.Message, MsgBoxStyle.Critical, "Error")
            Return False
        End Try
    End Function

    ' Tombol Tambah
    Private Sub btnTambah_Click(sender As Object, e As EventArgs) Handles btnTambah.Click
        Try
            AktifkanKontrol()
            BersihkanForm()
            btnTambah.Enabled = False
            ' txtIDPelanggan.Enabled = True HAPUS INI, ID AUTO-INCREMENT
            txtNamaPelanggan.Focus() ' Fokus ke field nama, bukan ID
        Catch ex As Exception
            MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' Tombol Simpan
    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click

        If Not ValidateInput() Then Exit Sub

        Try
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()

            ' Insert data baru (TIDAK MENYERTakan ID_PELANGGAN di query dan parameter)
            cmd.CommandText = "INSERT INTO Pelanggan (NAMA_PELANGGAN, TANGGAL_TRANSAKSI, JENIS_PAKET, HARGA_JAM, LAMA_MAIN, POTONGAN, TOTAL_BAYAR) VALUES (@nama, @tanggal, @jenis, @harga, @lama, @potongan, @total)"
            cmd.Parameters.Clear()
            ' cmd.Parameters.AddWithValue("@id", txtIDPelanggan.Text.Trim()) HAPUS INI
            cmd.Parameters.AddWithValue("@nama", txtNamaPelanggan.Text.Trim())
            cmd.Parameters.AddWithValue("@tanggal", dtpTanggalTransaksi.Value.ToString("yyyy-MM-dd"))
            cmd.Parameters.AddWithValue("@jenis", cmbJenisPaket.Text)
            cmd.Parameters.AddWithValue("@harga", hargaPaket)
            cmd.Parameters.AddWithValue("@lama", Convert.ToInt32(txtLamaMain.Text))
            cmd.Parameters.AddWithValue("@potongan", Convert.ToDecimal(txtPotongan.Text.Replace(".", "").Replace(",", "")))
            cmd.Parameters.AddWithValue("@total", totalBayarHasilHitung)

            cmd.ExecuteNonQuery()

            MsgBox("Data berhasil disimpan!", MsgBoxStyle.Information, "Sukses")
            TampilkanDataPelanggan()
            BersihkanForm()
            NonAktifkanKontrol()
            btnTambah.Enabled = True

        Catch ex As Exception
            MsgBox("Gagal simpan: " & ex.Message, MsgBoxStyle.Critical, "Error Database")
        Finally
            If conn.State = ConnectionState.Open Then conn.Close()
        End Try
    End Sub

    ' Tombol Batal
    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        Try
            BersihkanForm()
            NonAktifkanKontrol()
            btnTambah.Enabled = True
        Catch ex As Exception
            MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' Tombol Update
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        ' Validasi ini tetap ada karena untuk update, ID harus dipilih dari DGV
        If txtIDPelanggan.Text.Trim() = "" Then
            MsgBox("Pilih data yang akan diupdate terlebih dahulu!", MsgBoxStyle.Exclamation, "Peringatan")
            Return
        End If

        If Not ValidateInput() Then Exit Sub

        If MsgBox("Yakin ingin mengupdate data ini?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Konfirmasi Update") = MsgBoxResult.Yes Then
            Try
                If conn.State = ConnectionState.Open Then conn.Close()
                conn.Open()

                cmd.Connection = conn
                cmd.CommandText = "UPDATE Pelanggan SET NAMA_PELANGGAN=@nama, TANGGAL_TRANSAKSI=@tanggal, JENIS_PAKET=@jenis, HARGA_JAM=@harga, LAMA_MAIN=@lama, POTONGAN=@potongan, TOTAL_BAYAR=@total WHERE ID_PELANGGAN=@id"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@nama", txtNamaPelanggan.Text.Trim())
                cmd.Parameters.AddWithValue("@tanggal", dtpTanggalTransaksi.Value.ToString("yyyy-MM-dd"))
                cmd.Parameters.AddWithValue("@jenis", cmbJenisPaket.Text)
                cmd.Parameters.AddWithValue("@harga", hargaPaket)
                cmd.Parameters.AddWithValue("@lama", Convert.ToInt32(txtLamaMain.Text))
                cmd.Parameters.AddWithValue("@potongan", Convert.ToDecimal(txtPotongan.Text.Replace(".", "").Replace(",", "")))
                cmd.Parameters.AddWithValue("@total", totalBayarHasilHitung)
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtIDPelanggan.Text)) ' ID digunakan untuk WHERE clause

                Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                If rowsAffected > 0 Then
                    MsgBox("Data berhasil diupdate!", MsgBoxStyle.Information, "Sukses")
                    TampilkanDataPelanggan()
                    BersihkanForm()
                    NonAktifkanKontrol()
                    btnTambah.Enabled = True
                Else
                    MsgBox("Data tidak ditemukan atau tidak ada perubahan!", MsgBoxStyle.Exclamation, "Peringatan")
                End If

            Catch ex As Exception
                MsgBox("Gagal update: " & ex.Message, MsgBoxStyle.Critical, "Error Database")
            Finally
                If conn.State = ConnectionState.Open Then conn.Close()
            End Try
        End If
    End Sub

    ' Tombol Hapus
    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        ' Validasi ini tetap ada karena untuk hapus, ID harus dipilih dari DGV
        If txtIDPelanggan.Text.Trim() = "" Then
            MsgBox("Pilih data yang akan dihapus terlebih dahulu!", MsgBoxStyle.Exclamation, "Peringatan")
            Return
        End If

        If MsgBox("Yakin ingin menghapus data pelanggan " & txtNamaPelanggan.Text & "?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Konfirmasi Hapus") = MsgBoxResult.Yes Then
            Try
                If conn.State = ConnectionState.Open Then conn.Close()
                conn.Open()

                cmd.Connection = conn
                cmd.CommandText = "DELETE FROM Pelanggan WHERE ID_PELANGGAN=@id"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtIDPelanggan.Text))

                Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                If rowsAffected > 0 Then
                    MsgBox("Data berhasil dihapus!", MsgBoxStyle.Information, "Sukses")
                    TampilkanDataPelanggan()
                    BersihkanForm()
                    NonAktifkanKontrol()
                    btnTambah.Enabled = True
                Else
                    MsgBox("Data tidak ditemukan!", MsgBoxStyle.Exclamation, "Peringatan")
                End If

            Catch ex As Exception
                MsgBox("Gagal hapus: " & ex.Message, MsgBoxStyle.Critical, "Error Database")
            Finally
                If conn.State = ConnectionState.Open Then conn.Close()
            End Try
        End If
    End Sub

    ' Tombol Keluar
    Private Sub btnKeluar_Click(sender As Object, e As EventArgs) Handles btnKeluar.Click
        If MsgBox("Yakin ingin keluar dari aplikasi?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Konfirmasi Keluar") = MsgBoxResult.Yes Then
            Try
                If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                    conn.Close()
                End If
            Catch ex As Exception
                ' Handle quietly, as closing form might throw if connection is already broken
            End Try
            Me.Close()
        End If
    End Sub

    ' DataGridView CellClick Event
    Private Sub dgvPelanggan_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvPelanggan.CellClick
        Try
            If e.RowIndex >= 0 AndAlso e.RowIndex < dgvPelanggan.Rows.Count Then
                Dim row As DataGridViewRow = dgvPelanggan.Rows(e.RowIndex)

                AktifkanKontrol()
                txtIDPelanggan.Enabled = False ' ID tidak bisa diedit setelah dipilih

                If row.Cells("ID").Value IsNot Nothing Then
                    txtIDPelanggan.Text = row.Cells("ID").Value.ToString()
                Else
                    txtIDPelanggan.Text = ""
                End If

                If row.Cells("Nama Pelanggan").Value IsNot Nothing Then
                    txtNamaPelanggan.Text = row.Cells("Nama Pelanggan").Value.ToString()
                Else
                    txtNamaPelanggan.Text = ""
                End If

                If row.Cells("Tanggal").Value IsNot Nothing Then
                    Dim tanggalValue As Date
                    If Date.TryParse(row.Cells("Tanggal").Value.ToString(), tanggalValue) Then
                        dtpTanggalTransaksi.Value = tanggalValue
                    Else
                        dtpTanggalTransaksi.Value = DateTime.Now
                    End If
                Else
                    dtpTanggalTransaksi.Value = DateTime.Now
                End If

                If row.Cells("Jenis Paket").Value IsNot Nothing Then
                    cmbJenisPaket.Text = row.Cells("Jenis Paket").Value.ToString()
                Else
                    cmbJenisPaket.SelectedIndex = -1
                End If

                If row.Cells("Harga/Jam").Value IsNot Nothing Then
                    hargaPaket = Convert.ToDecimal(row.Cells("Harga/Jam").Value)
                    txtHargaJam.Text = hargaPaket.ToString("N0")
                Else
                    txtHargaJam.Text = ""
                    hargaPaket = 0
                End If

                If row.Cells("Lama Main").Value IsNot Nothing Then
                    txtLamaMain.Text = row.Cells("Lama Main").Value.ToString()
                Else
                    txtLamaMain.Text = ""
                End If

                If row.Cells("Potongan").Value IsNot Nothing Then
                    txtPotongan.Text = row.Cells("Potongan").Value.ToString()
                Else
                    txtPotongan.Text = ""
                End If

                If row.Cells("Total Bayar").Value IsNot Nothing Then
                    totalBayarHasilHitung = Convert.ToDecimal(row.Cells("Total Bayar").Value)
                    txtTotalBayar.Text = totalBayarHasilHitung.ToString("N0")
                Else
                    txtTotalBayar.Text = ""
                    totalBayarHasilHitung = 0
                End If

                btnSimpan.Enabled = False
                btnUpdate.Enabled = True
                btnHapus.Enabled = True
                btnTambah.Enabled = False

            End If
        Catch ex As Exception
            MsgBox("Error saat memilih data: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' Event untuk KeyDown di txtIDPelanggan (Hanya untuk mencari data yang sudah ada)
    Private Sub txtIDPelanggan_KeyDown(sender As Object, e As KeyEventArgs) Handles txtIDPelanggan.KeyDown
        If e.KeyCode = Keys.Enter And txtIDPelanggan.Text.Trim() <> "" Then
            Try
                If conn.State = ConnectionState.Open Then conn.Close()
                conn.Open()

                cmd.Connection = conn
                cmd.CommandText = "SELECT ID_PELANGGAN, NAMA_PELANGGAN, TANGGAL_TRANSAKSI, JENIS_PAKET, HARGA_JAM, LAMA_MAIN, POTONGAN, TOTAL_BAYAR FROM Pelanggan WHERE ID_PELANGGAN=@id"
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@id", txtIDPelanggan.Text.Trim())

                reader = cmd.ExecuteReader()

                If reader.Read() Then
                    MsgBox("Data sudah ada, masuk mode Update/Hapus!", MsgBoxStyle.Information, "Info")
                    txtNamaPelanggan.Text = reader("NAMA_PELANGGAN").ToString()
                    dtpTanggalTransaksi.Value = Convert.ToDateTime(reader("TANGGAL_TRANSAKSI"))
                    cmbJenisPaket.Text = reader("JENIS_PAKET").ToString()
                    hargaPaket = Convert.ToDecimal(reader("HARGA_JAM"))
                    txtHargaJam.Text = hargaPaket.ToString("N0")
                    txtLamaMain.Text = reader("LAMA_MAIN").ToString()
                    txtPotongan.Text = Convert.ToDecimal(reader("POTONGAN")).ToString("N0")
                    totalBayarHasilHitung = Convert.ToDecimal(reader("TOTAL_BAYAR"))
                    txtTotalBayar.Text = totalBayarHasilHitung.ToString("N0")

                    AktifkanKontrol()
                    txtIDPelanggan.Enabled = False ' ID tidak bisa diubah saat update
                    btnSimpan.Enabled = False
                    btnUpdate.Enabled = True
                    btnHapus.Enabled = True
                    btnTambah.Enabled = False

                Else
                    MsgBox("ID Pelanggan tidak ditemukan. Masukkan ID yang ada atau klik Tambah untuk entri baru.", MsgBoxStyle.Information, "Info")
                    BersihkanForm()
                    txtIDPelanggan.Text = "" ' Kosongkan ID jika tidak ditemukan
                    NonAktifkanKontrol() ' Kembali ke state awal
                    btnTambah.Enabled = True ' Aktifkan kembali tombol Tambah
                End If

            Catch ex As Exception
                MsgBox("Error saat mencari data ID Pelanggan: " & ex.Message, MsgBoxStyle.Critical, "Error Database")
            Finally
                If reader IsNot Nothing AndAlso Not reader.IsClosed Then reader.Close()
                If conn.State = ConnectionState.Open Then conn.Close()
            End Try
        End If
    End Sub

    ' Form Closing Event
    Private Sub frmDataPelanggan_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Try
            If conn IsNot Nothing AndAlso conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        Catch ex As Exception
            ' Handle quietly, as closing form might throw if connection is already broken
        End Try
    End Sub

    ' Method untuk refresh data (ini dipanggil setelah simpan/update/hapus)
    Private Sub RefreshData()
        Try
            TampilkanDataPelanggan()
            BersihkanForm()
            NonAktifkanKontrol()
            btnTambah.Enabled = True
        Catch ex As Exception
            MsgBox("Error refresh data: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

End Class